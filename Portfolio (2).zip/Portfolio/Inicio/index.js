function abrirTela(){
    window.location.assign("../pagina/index.html");
}